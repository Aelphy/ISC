import sys
sys.path.append('./build')
import perda

print(perda.f())
