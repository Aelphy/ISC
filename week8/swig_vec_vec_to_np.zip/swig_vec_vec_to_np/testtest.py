import sys
sys.path.append('./build')
import project

print(project.f())
