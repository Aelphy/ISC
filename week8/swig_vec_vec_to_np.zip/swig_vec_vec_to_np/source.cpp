#include <vector>
#include <iostream>

std::vector<std::vector<float>> f() {
  std::vector<std::vector<float>> r;
  std::vector<float> tmp1;
  std::vector<float> tmp2;

  tmp1.push_back(0.1);
  tmp1.push_back(0.2);
  tmp1.push_back(0.3);

  tmp2.push_back(0.4);
  tmp2.push_back(0.5);
  tmp2.push_back(0.6);

  r.push_back(tmp1);
  r.push_back(tmp2);

  return r;
}
